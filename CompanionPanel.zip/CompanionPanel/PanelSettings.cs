using Microsoft.Maui.Storage;

namespace CompanionPanel;

/// <summary>Small values saved locally with MAUI Preferences (SharedPreferences on Android).</summary>
public static class PanelSettings
{
    const string DarkKey = "dark_theme";
    const string MinutesKey = "timer_minutes";

    public static bool DarkTheme
    {
        get => Preferences.Default.Get(DarkKey, false);
        set => Preferences.Default.Set(DarkKey, value);
    }

    public static int TimerMinutes
    {
        get => Preferences.Default.Get(MinutesKey, 10);
        set => Preferences.Default.Set(MinutesKey, value);
    }
}
