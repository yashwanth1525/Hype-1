# Companion Panel (.NET MAUI, Android, 32-bit ARM capable)

A standalone companion app: dark-theme preference, timer length preference,
a manual countdown timer, and personal notes saved locally.
It does not connect to or interact with any game.

Targets: `net10.0-android`, API 21+, ABIs armeabi-v7a (`android-arm`) and arm64-v8a (`android-arm64`).

NOTE: these files were written without a compiler available, so the first build
may need small fixes. Send me any error text and I will correct it.

## Option A: build on your PC

1. Install the .NET 10 SDK and a JDK (17 or 21).
2. `dotnet workload install maui-android`
3. Connect the phone (USB debugging on) and check `adb devices`.
4. Check the phone's ABI: `adb shell getprop ro.product.cpu.abilist`
5. Build, install and run (Debug):

       dotnet build -f net10.0-android -c Debug -r android-arm -t:Run

   If the phone lists arm64-v8a, use `-r android-arm64` instead.

## Option B: build in the cloud (GitHub Actions, no local SDK)

1. Create a new GitHub repository and upload these files, keeping the folder
   structure (including `.github/workflows/build-apk.yml`).
2. Open the Actions tab, pick "Build Android APK", and press Run workflow.
3. When it finishes, download the `CompanionPanel-apk` artifact, unzip it,
   copy the `-Signed.apk` to the phone, and allow "Install unknown apps".

The workflow signs with a throwaway key made on each run, so uninstall the old
version before installing a newer APK.
