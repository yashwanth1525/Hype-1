using Microsoft.Maui.Accessibility;
using Microsoft.Maui.Dispatching;
using Microsoft.Maui.Storage;

namespace CompanionPanel;

public partial class MainPage : ContentPage
{
    readonly IDispatcherTimer _timer;
    DateTime? _endsAtUtc;

    static readonly string NotesPath =
        Path.Combine(FileSystem.AppDataDirectory, "notes.txt");

    public MainPage()
    {
        InitializeComponent();

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(1);
        _timer.Tick += OnTick;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        DarkSwitch.IsToggled = PanelSettings.DarkTheme;
        MinutesSlider.Value = PanelSettings.TimerMinutes;
        MinutesLabel.Text = $"Timer length: {PanelSettings.TimerMinutes} min";
        ApplyTheme(PanelSettings.DarkTheme);

        if (File.Exists(NotesPath))
            NotesEditor.Text = await File.ReadAllTextAsync(NotesPath);
    }

    static void ApplyTheme(bool dark)
    {
        if (Application.Current is not null)
            Application.Current.UserAppTheme = dark ? AppTheme.Dark : AppTheme.Light;
    }

    void OnDarkToggled(object? sender, ToggledEventArgs e)
    {
        PanelSettings.DarkTheme = e.Value;
        ApplyTheme(e.Value);
    }

    void OnMinutesChanged(object? sender, ValueChangedEventArgs e)
    {
        int minutes = (int)Math.Round(e.NewValue);
        PanelSettings.TimerMinutes = minutes;
        MinutesLabel.Text = $"Timer length: {minutes} min";
    }

    void OnStartStopClicked(object? sender, EventArgs e)
    {
        if (_endsAtUtc is null)
        {
            _endsAtUtc = DateTime.UtcNow.AddMinutes(PanelSettings.TimerMinutes);
            StartStopButton.Text = "Stop";
            _timer.Start();
            OnTick(null, EventArgs.Empty);
        }
        else
        {
            StopTimer();
            TimerLabel.Text = "--:--";
        }
    }

    void OnTick(object? sender, EventArgs e)
    {
        if (_endsAtUtc is null)
            return;

        var remaining = _endsAtUtc.Value - DateTime.UtcNow;
        if (remaining <= TimeSpan.Zero)
        {
            StopTimer();
            TimerLabel.Text = "Done";
            SemanticScreenReader.Default.Announce("Timer finished");
            return;
        }

        TimerLabel.Text = $"{(int)remaining.TotalMinutes:00}:{remaining.Seconds:00}";
    }

    void StopTimer()
    {
        _timer.Stop();
        _endsAtUtc = null;
        StartStopButton.Text = "Start";
    }

    async void OnSaveNotesClicked(object? sender, EventArgs e)
    {
        await File.WriteAllTextAsync(NotesPath, NotesEditor.Text ?? string.Empty);
        StatusLabel.Text = $"Saved at {DateTime.Now:t}";
        SemanticScreenReader.Default.Announce("Notes saved");
    }
}
